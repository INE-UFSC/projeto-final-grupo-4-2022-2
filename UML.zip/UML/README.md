Documente aqui os diagramas UML criados pelo grupo. A ideia não é ter a versão final na primeira entrega. É comum que os diagramas evoluam com o desenvolvimento do projeto. 

Nessa quesito, serão avaliados o uso adequado das relações UML e a sintaxe adequada na descrição dos diagramas.